import java.util.ArrayList;

public class Driver {

	public static ArrayList<Integer> list ;
	public Driver() {
		
	}

	public static void main(String[] args) {
		Driver driver = new Driver();
		driver.fillList();
		driver.calcSD(list);

	}
	
	public void calcSD(ArrayList<Integer> list){
		double sum = 0;
		double count = 0;
		double mean = 0; 
		double value = 0;
		double valueTotal = 0;
		double variance = 0;
		double stdD = 0;
		for(Integer num:list){
			sum += num;
			count++;
		}
		mean = sum / count;
		System.out.println(mean);
		for(Integer num:list){
			value = Math.pow((num - mean), 2);
			valueTotal += value;
		}
		System.out.println(valueTotal);
		variance = valueTotal / count;
		System.out.println(variance);
		stdD = Math.sqrt(variance);
		System.out.printf("%.4f",stdD);
}
	public void fillList(){
	    list = new ArrayList<Integer>();
	    
		list.add(5);
		list.add(6);
		list.add(11);
		list.add(13);
		list.add(19);
		list.add(20);
		list.add(25);
		list.add(26);
		list.add(28);
		list.add(37);
		//5 6 11 13 19 20 25 26 28 37
	}
}