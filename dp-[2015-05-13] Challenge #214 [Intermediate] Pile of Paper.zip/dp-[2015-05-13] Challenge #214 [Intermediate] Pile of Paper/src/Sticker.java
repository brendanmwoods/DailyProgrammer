
public class Sticker {

	private int colour;
	private int topLeftX;
	private int topLeftY;
	private int width;
	private int height;
	
	public Sticker() {

	}

	public Sticker(String[] input) {
		this.colour = Integer.parseInt(input[0]);
		this.topLeftX = Integer.parseInt(input[1]);
		this.topLeftY = Integer.parseInt(input[2]);
		this.width = Integer.parseInt(input[3]);
		this.height = Integer.parseInt(input[4]);
	}

	public void printStickerDetails(){
		System.out.println("colour: " + colour);
		System.out.println("top left X: " + topLeftX);
		System.out.println("top left Y: " + topLeftY);
		System.out.println("width: " + width);
		System.out.println("height: " + height);
	}
	
	/**
	 * @return the colour
	 */
	public int getColour() {
		return colour;
	}

	/**
	 * @param colour the colour to set
	 */
	public void setColour(int colour) {
		this.colour = colour;
	}

	/**
	 * @return the topLeftX
	 */
	public int getTopLeftX() {
		return topLeftX;
	}

	/**
	 * @param topLeftX the topLeftX to set
	 */
	public void setTopLeftX(int topLeftX) {
		this.topLeftX = topLeftX;
	}
	
	/**
	 * @return the topLeftY
	 */
	public int getTopLeftY() {
		return topLeftY;
	}

	/**
	 * @param topLeftY the topLeftY to set
	 */
	public void setTopLeftY(int topLeftY) {
		this.topLeftY = topLeftY;
	}

	/**
	 * @return the width
	 */
	public int getWidth() {
		return width;
	}

	/**
	 * @param width the width to set
	 */
	public void setWidth(int width) {
		this.width = width;
	}

	/**
	 * @return the height
	 */
	public int getHeight() {
		return height;
	}

	/**
	 * @param height the height to set
	 */
	public void setHeight(int height) {
		this.height = height;
	}

	
}
