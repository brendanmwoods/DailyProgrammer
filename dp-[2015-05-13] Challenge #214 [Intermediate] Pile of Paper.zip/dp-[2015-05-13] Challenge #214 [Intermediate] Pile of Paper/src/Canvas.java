
public class Canvas {

	private int[][] paper;

	/**
	 * Constructor for our initial canvas. The two arguements are dimensions (x,y).
	 * @param a sets rows
	 * @param b sets columns
	 */
	public Canvas(int x , int y) {
		paper = new int[y][x];
	}

	/**
	 * Prints out the current state of the canvas.
	 */
	public void printPaper(){
		for(int a = 0; a < paper.length; a++){
			for(int b = 0; b < paper[a].length;b++){
				System.out.print(paper[a][b]);
			}
			System.out.println();
		}
	}
	

	/**
	 * Add a new sticker to the canvas. 
	 */
	
	public void addSticker(Sticker sticker){
		for(int a = sticker.getTopLeftX(); a < (sticker.getTopLeftX() + sticker.getHeight()); a++){
			for(int b = sticker.getTopLeftY(); b < sticker.getTopLeftY() + sticker.getWidth(); b++){
				paper[a][b] = sticker.getColour();
			}
		}
	}
	
	public void printAreaStats() {
		int zeroCount = 0;
		int oneCount = 0;
		int twoCount = 0;

		for (int a = 0; a < paper.length; a++) {
			for (int b = 0; b < paper[a].length; b++) {
				if (paper[a][b] == 0) {
					zeroCount++;
				} else if (paper[a][b] == 1) {
					oneCount++;
				} else if (paper[a][b] == 2) {
					twoCount++;
				}
			}
		}
		System.out.println("0: " + zeroCount);
		System.out.println("1: " + oneCount);
		System.out.println("2: " + twoCount);
	}
}
	

