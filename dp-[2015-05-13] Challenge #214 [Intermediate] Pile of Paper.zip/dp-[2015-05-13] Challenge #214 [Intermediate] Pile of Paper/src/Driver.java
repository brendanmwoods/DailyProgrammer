//[2015-05-13] Challenge #214 [Intermediate] Pile of Paper

public class Driver {

	public static String[] input;
	
	public Driver() {

	}

	public static void main(String[] args) {
		
		//create paper
		Canvas paper = new Canvas(20,10);
		
		//print empty canvas
		paper.printPaper();
		
		//create first sticker from input
		Sticker sticker = new Sticker(sendStickerInfo("1 5 5 10 3"));
		Sticker sticker2 = new Sticker(sendStickerInfo("2 0 0 7 7 "));
		
		//print sticker details
		sticker.printStickerDetails();
		
		//add sticker to canvas
		paper.addSticker(sticker);
		paper.addSticker(sticker2);
		
		//reprint the canvas
		paper.printPaper();
		
		//print area stats
		paper.printAreaStats();
	}

	public static String[] sendStickerInfo(String inputString){
		String[] inputArray = inputString.split(" ");
		return inputArray;
	}
	
}

