import java.util.Scanner;


public class Solver {

	private String input;
	
	public Solver() {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Input your text, yo");
		input = scanner.nextLine();
		scanner.close();
		this.solve();
	}

	public void solve(){
		for(int index = 0; index < input.length(); index++){
			if(input.charAt(index) == 'a' ||
				input.charAt(index) == 'e' ||
				input.charAt(index) == 'i' ||
				input.charAt(index) == 'o' ||	
				input.charAt(index) == 'u'){
				System.out.print(input.charAt(index));
			}
			else{
				System.out.print(input.charAt(index)
						+ "o" + input.charAt(index));
			}
		}
	}
	
}
